// @TODO: YOUR CODE HERE!
var svgWidth = 960;
var svgHeight = 500;

var margin = {
    top : 20,
    right : 50,
    bottom : 60,
    left : 50
}

var width = svgWidth - margin.left - margin.right;
var height = svgHeight - margin.bottom - margin.top;

var svg =d3.select(".chart")
    .append("svg")
    .attr("width", svgWidth)
    .attr("height", svgHeight);


var chartGroup = svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`);

d3.csv("assets/data/data.csv").then(function(aData){
    aData.forEach(function(data){
        data.healthcare = +data.healthcare;
        data.poverty = +data.poverty;
        data.smokes = +data.smokes;
        data.age = +data.age;
    });

    var xLinearScale1 = d3.scaleLinear()
        .domain([d3.extent(aData, d=>d.poverty)])
        .range([0,width]);
    
    var xLinearScale2 = d3.scaleLinear()
        .domain([d3.extent(aData, d=>d.age)])
        .range([0,width]);

    var yLinearScale1 = d3.scaleLinear()
        .domain([0,d3.max(aData, d=>d.healthcare)])
        .range([height,0]);

    var yLinearScale2 = d3.scaleLinear()
        .domain([0,d3.max(aData, d=>d.smokes)])
        .range([height,0]);



    chartGroup.selectAll("circle")
        .data(aData)
        .enter()
        .append("circle")
        .attr("cx", function(d) {
            return xLinearScale1(d.poverty);
            })
        .attr("cy", function(d){
            return yLinearScale1(d.healthcare);
            })
        .attr("r", 1.5)
        .attr("fill", "blue")
        .attr("opacity", "0.5");

}).catch(function(error){
    console.log(error);
});
